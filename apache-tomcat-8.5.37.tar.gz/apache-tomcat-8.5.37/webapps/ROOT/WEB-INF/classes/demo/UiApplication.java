package demo;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
@Controller
public class UiApplication extends SpringBootServletInitializer  {

	  @GetMapping(value = "/{path:[^\\.]*}")
	    public String redirect() {
	        return "forward:/";
	    }
	  @Override
	  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
			return builder.sources(UiApplication.class);
		}

	  
    public static void main(String[] args) {
        SpringApplication.run(UiApplication.class, args);
    }

   

}