package demo;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.bind.DatatypeConverter;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import net.rcarz.jiraclient.BasicCredentials;
import net.rcarz.jiraclient.Comment;
import net.rcarz.jiraclient.CustomFieldOption;
import net.rcarz.jiraclient.Field;
import net.rcarz.jiraclient.Issue;
import net.rcarz.jiraclient.JiraClient;
import net.rcarz.jiraclient.JiraException;

@SpringBootApplication
@RestController
@RequestMapping("/test")
public class ControllerEndpoint {

		
    @GetMapping("/user")
    @ResponseBody
    public Principal user(Principal user) {
        return user;
    }

    @GetMapping("/resource")
    @ResponseBody
    public Map<String, Object> home() {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("id", UUID.randomUUID().toString());
        model.put("content", "Hello World");
        return model;
    }

   
    @RequestMapping(value = "/jenkins", method = RequestMethod.POST)
    @ResponseBody
    public static String add(String test) throws IOException
    {
    	System.out.println("test");
		String Crumb="Jenkins-Crumb:56a6bc4c8522ff4b8211bd0f49d53f9f";//Jenkinsurlc/rumbIssuer/api/json Gives This value in json format
		String Job="http://admin:11fcaf5943065e783ff4c5b489d1074948@ec2-52-62-16-126.ap-southeast-2.compute.amazonaws.com:8080/job/SeleniumDummy/build/";// Programmatically Get curl --silent --basic http://<username>:<password>@<jenkins-url>/me/configure | hxselect '#apiToken' | sed 's/.*value="\([^"]*\)".*/\1\n/g'

		String remote =test;
		ProcessBuilder p1=new ProcessBuilder("curl","-X","POST",Job+"-H"+Crumb);
		BufferedReader reader = new BufferedReader(new InputStreamReader(p1.start().getInputStream()));//executing commands using process builder
				
	        
        String line = null ;
        while ((line = reader.readLine())!= null){
            System.out.println(line);
        }
		return test;
    }
    @RequestMapping(value = "/bamboo", method = RequestMethod.GET)
    @ResponseBody
    public static void addBamboo() throws IOException
    {
    	ProcessBuilder p1=new ProcessBuilder("curl","-X","POST","--user","admin:admin","http://localhost:8085/rest/api/latest/queue/DUM-TES?executeAllStages=true");
		BufferedReader reader = new BufferedReader(new InputStreamReader(p1.start().getInputStream()));
		
	        
        String line = null ;
        while ((line = reader.readLine())!= null){
            System.out.println(line);
        }
    }
    @GetMapping("/jobs")//url endpoint
    @ResponseBody
    public static List<String> getAll() {
       
    	List<String> jobs= new ArrayList<String>();

   	 	  try
   	 	  {
   	 		System.out.println("reached here");
			URL url = new URL("http://admin:11fcaf5943065e783ff4c5b489d1074948@ec2-52-62-16-126.ap-southeast-2.compute.amazonaws.com:8080/api/json?pretty=true"); // Jenkins URL localhost:8080, job named
																				// 'test'
			String user = "admin"; // username
			String pass = "admin"; // password or API token
			String authStr = user + ":" + pass;
			String encoding = DatatypeConverter.printBase64Binary(authStr.getBytes("utf-8"));

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();//Opening a Http connection
			connection.setRequestMethod("GET");
			connection.setDoOutput(true);
			connection.setRequestProperty("Authorization", "Basic" + encoding);//basic auth 

			InputStream content = connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(content));
			String line;
			while ((line = in.readLine()) != null) {
				
				//System.out.println(line);
				if(line.contains("url") && line.contains("job"))
				{
					System.out.println();
					jobs.add("Job Name : "+ line.substring(41, (line.length()-3)));
				}
			}
   	    } catch(Exception e) {
   	      e.printStackTrace();
   	      System.out.println("reached error");
   	    }
   	 	  System.out.println("printing all "+jobs);
        return jobs;
    }
    @RequestMapping(value = "/jira", method = RequestMethod.POST)
    @ResponseBody
    public static void Jira() throws JiraException, IOException
    {
    	String [] command = {"/usr/local/tomcat7/test.sh"};
    	ProcessBuilder p1=new ProcessBuilder(command);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(p1.start().getInputStream()));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//executing commands using process builder
				
	        
        String line = null ;
        while ((line = reader.readLine())!= null){
            System.out.println(line);
        }
    }
    @RequestMapping(value = "/jenkinsLast", method = RequestMethod.POST)
    @ResponseBody
    public static void jenkinsLastBuild() throws IOException
    {
    	List<String> jobs= new ArrayList<String>();

 	 	  try
 	 	  {
 	 		System.out.println("reached here");
			URL url = new URL("http://admin:admin@ec2-52-62-16-126.ap-southeast-2.compute.amazonaws.com:8080/job/Selenium/lastBuild/api/xml"); // Jenkins URL localhost:8080, job named
																				// 'test'
			String user = "user"; // username
			String pass = "user123"; // password or API token
			String authStr = user + ":" + pass;
			String encoding = DatatypeConverter.printBase64Binary(authStr.getBytes("utf-8"));

			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			connection.setDoOutput(true);
			connection.setRequestProperty("Authorization", "Basic" + encoding);//basic auth 

			InputStream content = connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(content));
			String line=in.readLine();
			String[] data =line.split("\\>\\<");
			for(int i=0;i<data.length;i++)
			{
				System.out.println("--***--");
				System.out.println(data[i]);
				if(data[i].contains("duration>"))
				{
					System.out.println("Entered Here");
					String[] text = data[i].split("\\>|\\<");
					for(int j=0;j<text.length;j++)
					{
						System.out.println(text[j]);
					}
				}
			}
 	    } catch(Exception e) {
 	      e.printStackTrace();
 	      System.out.println("reached error");
 	    }
    	
    }
    
    @RequestMapping(value = "/jira123", method = RequestMethod.POST)
    @ResponseBody
    public static void jira123() throws JiraException
    {
    	 
    	    	  System.out.println("Got here");
    	    	  BasicCredentials creds = new BasicCredentials("admin", "admin12345");
    	          JiraClient jira = new JiraClient("https://revolutionitqa.atlassian.net", creds);

    	          try {
    	              /* Retrieve issue TEST-123 from JIRA. We'll get an exception if this fails. */
    	              final Issue issue = jira.getIssue("REV-3");

    	              /* Print the issue key. */
    	              System.out.println(issue);

    	              /* You can also do it like this: */
    	              System.out.println(issue.getKey());

    	              /* Vote for the issue. */
    	              //issue.vote();

    	              /* And also watch it. Add Robin too. */
    	              issue.addWatcher(jira.getSelf());
    	             // issue.addWatcher("robin");

    	              /* Open the issue and assign it to batman. */
    	              issue.transition()
    	                  .execute("Selected for Development");
    	                  
    	              /* Assign the issue */
    	              issue.update()
    	                  .field(Field.ISSUE_TYPE, "story")
    	                  .execute();

    	              /* Add two comments, with one limited to the developer role. */
    	              issue.addComment("Updating Autonomously");
    	              //issue.addComment("He tried to send a whole Internet!", "role", "Developers");

    	              /* Print the reporter's username and then the display name */
    	          
    	              final Issue issue1 = jira.getIssue("REV-4");
    	              issue1.transition().execute("Selected for Development");

    	            

    	             
    	          } catch (JiraException ex) {
    	              System.err.println(ex.getMessage());

    	              if (ex.getCause() != null)
    	                  System.err.println(ex.getCause().getMessage());
    	          }
    }
}

